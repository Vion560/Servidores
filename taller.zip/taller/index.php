<?php
    $correo= fopen("cargarmarcas.csv","r") or die("No se ha podido leer el fichero!");
        while ($data = fgets($correo)) {
            $marca[] = explode(",", $data)[0];
            $value[] = explode(",", $data)[1];
        }
    fclose ($correo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="recogeDatos.php" method="post">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" id="nombre">
        <br></br>
        <label for="matricula">Matrícula:</label>
        <input type="text" name="matricula" id="matricula">
        <br></br>
        <label for="telefono">Teléfono:</label>
        <input type="tel" name="telefono" id="telefono">
        <br></br>
        <label for="email">Correo:</label>
        <input type="email" name="email" id="email">
        <br></br>
        <label for="marca">Marca:</label>
        <select id="marca" name="marca">
            <option value=<?php echo $value[0]?>><?php echo $marca[0]?></option>
            <option value=<?php echo $value[1]?>><?php echo $marca[1]?></option>
            <option value=<?php echo $value[2]?>><?php echo $marca[2]?></option>
            <option value=<?php echo $value[3]?>><?php echo $marca[3]?></option>
            <!--<select multiple name="marca[]"> 
            <option value=<?php for($i = 0;$i<count($value);$i++){echo $value[$i];}?>><?php echo $marca[$i];?></option>
            -->
        </select>
        <br></br>
        <button type="submit">Enviar datos</button>
        </form>
</body>
</html>