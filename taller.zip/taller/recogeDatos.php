<?php
    $myfile = fopen("listaguardados.csv", "a") or die("No se ha podido ejecutar el archivo csv!");
    $nombre=$_POST["nombre"];
    $matricula=$_POST["matricula"];
    $telefono=$_POST["telefono"];
    $correo = $_POST["email"];
    $marca = $_POST["marca"];
    fwrite($myfile, "$nombre,$matricula,$telefono,$correo,$marca \n");
    fclose($myfile);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vercoches</title>
</head>
<body>
<div class="contenedor">
        <h1>Coches</h1>
        <table class="tabla">
            <tr>
                <th>Nombre</th>
                <th>Matrícula</th>
                <th>Teléfono</th>
                <th>Correo</th>
                <th>Marca</th>
            </tr>

            <?php
            $myfile = fopen("listaguardados.csv", "r") or die("No se ha podido leer el fichero!");

            while (!feof($myfile)) {
                $frase = fgets($myfile);
                $arrayFrase = explode(",", $frase);

                if (count($arrayFrase) == 5) {
                    echo "<tr>";
                    echo "<td>$arrayFrase[0]</td>";
                    echo "<td>$arrayFrase[1]</td>";
                    echo "<td>$arrayFrase[2]</td>";
                    echo "<td>$arrayFrase[3]</td>";
                    echo "<td>$arrayFrase[4]</td>";
                    echo "</tr>";
                }
            }
            fclose($myfile);
            ?>
        </table>
    </div>
</body>
</html>