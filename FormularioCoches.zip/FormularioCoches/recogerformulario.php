<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    </style>
</head>
<body>
    <?php
        $nombre= $_POST['nombre'];
        $matricula= $_POST['matricula'];
        $telefono= $_POST['telefono'];
        $email= $_POST['email'];
        $marca= $_POST['marca'];  
        $seguro= $_POST['radio'];       
    ?>
    <table border>
        <tr>
            <th>Nombre</th>
            <td> <?php echo $nombre ?></td>    
        </tr>  
        <tr>      
            <th>matricula</th>
            <td><?php echo $matricula ?></td>
        </tr>
        <tr>
            <th>telefono</th>
            <td><?php echo $telefono ?></td>
        </tr>
        <tr>
            <th>email</th>
            <td><?php echo $email ?></td>
        </tr>
        <tr>
            <th>Marca</th>
            <td><?php if ($_POST['marca'] == "Seat")
                        {
                        echo "Tiene un Seat <br>";
                        }else if ($_POST['marca'] == "Ferrari")
                        {
                        echo "Tiene un Ferrari <br>";
                        }else if ($_POST['marca'] == "Volvo")
                        {
                        echo "Tiene un Volvo <br>";
                        }else if ($_POST['marca'] == "Tesla")
                        {
                        echo "Tiene un Tesla <br>";
                        }       
            ?></td>
        </tr>
        <tr>
            <th>Seguro</th>
            <td><?php if ($_POST['radio'])
                        {
                        echo $seguro ."<br>";
                        }
            ?></td>
        </tr>
        <tr>
            <th>Hora de llamada</th>
            <td><?php 
                    for($i = 1;$i < 4;$i +=1){
                        if(isset($_POST["call$i"])){
                            echo $_POST["call$i"];
                        }
                    }
            ?></td>
        </tr>
    </table>
</body>
</html>